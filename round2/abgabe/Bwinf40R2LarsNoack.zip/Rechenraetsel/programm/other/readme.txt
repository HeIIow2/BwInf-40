um test laufen zu lassen verschieben sie es zu rechenrätsel.py. Es wird times.csv erstellen/dort hinzufügen

um create_time_graph.py laufen zu lassen muss im gleichen ordner times.csv vorhanden sein. es mus matplotlib installiert sein.